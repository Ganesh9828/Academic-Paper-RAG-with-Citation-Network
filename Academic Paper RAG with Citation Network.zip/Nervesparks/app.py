import streamlit as st
from citation_utils import process_all_papers, build_citation_graph
from vector_db import VectorDB
from retrieval import retrieve_relevant_docs
from trend_analysis import find_seminal_works, find_research_trends

st.set_page_config(page_title="Academic Paper RAG", layout="wide")

st.title(" Academic Paper RAG with Citation Network")

st.write(

)

@st.cache_resource(show_spinner=True)
def initialize():

    papers = process_all_papers("data")
    if not papers:
        st.warning("No PDF files found in the 'data/' folder. Please add your papers.")

    citation_graph = build_citation_graph(papers)

    vector_db = VectorDB()
    vector_db.add_documents(papers)
    return papers, citation_graph, vector_db

papers, citation_graph, vector_db = initialize()

query = st.text_input("Enter your research query:")

if query:
    with st.spinner("Searching relevant documents..."):
        results = retrieve_relevant_docs(vector_db, query)

    st.subheader(" Retrieved Documents")
    for doc in results:
        st.markdown(f"**{doc['filename']}**")
        st.write(doc["text"][:500] + " ...")
    st.subheader(" Seminal Works (Top cited papers)")
    seminal_papers = find_seminal_works(citation_graph)
    for paper in seminal_papers:
        st.write(paper)

    st.subheader(" Recent Research Trends (Top bigrams)")
    trends = find_research_trends(papers)
    for trend in trends:
        st.write(f"- {trend}")