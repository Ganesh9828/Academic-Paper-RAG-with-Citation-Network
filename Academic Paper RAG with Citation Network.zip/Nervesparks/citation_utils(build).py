
import networkx as nx

def build_citation_graph(papers):
    G = nx.DiGraph()

    for paper in papers:
        G.add_node(paper["filename"])

    for paper in papers:
        for citation in paper["citations"]:

            target_paper = next((p["filename"] for p in papers if citation in p["text"]), None)
            if target_paper:
                G.add_edge(paper["filename"], target_paper)
    return G