
import re
import os
from PyPDF2 import PdfReader

def extract_text_from_pdf(pdf_path):
    reader = PdfReader(pdf_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    return text

def parse_citations(text):

    square = re.findall(r'\[\d+\]', text)
    author_year = re.findall(r'\([A-Za-z]+, \d{4}\)', text)
    return set(square + author_year)

def process_all_papers(data_folder):
    papers = []
    for fname in os.listdir(data_folder):
        if fname.endswith(".pdf"):
            path = os.path.join(data_folder, fname)
            text = extract_text_from_pdf(path)
            citations = parse_citations(text)
            papers.append({
                "filename": fname,
                "text": text,
                "citations": citations,
            })
    return papers