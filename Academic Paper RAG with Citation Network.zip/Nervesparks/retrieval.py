def retrieve_relevant_docs(vector_db, query):
    results = vector_db.search(query)
    retrieved_docs = []
    for doc, meta in zip(results['documents'][0], results['metadatas'][0]):
        retrieved_docs.append({"text": doc, "filename": meta["filename"]})
    return retrieved_docs