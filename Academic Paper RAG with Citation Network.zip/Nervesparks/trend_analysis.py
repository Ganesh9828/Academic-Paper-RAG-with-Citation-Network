def find_seminal_works(graph, top_k=3):

    ranks = sorted(graph.in_degree, key=lambda x: x[1], reverse=True)
    return [node for node, _ in ranks[:top_k]]

def find_research_trends(papers):

    from sklearn.feature_extraction.text import CountVectorizer
    vec = CountVectorizer(ngram_range=(2,2), max_features=5)
    texts = [p["text"] for p in papers]
    X = vec.fit_transform(texts)
    top_trends = vec.get_feature_names_out()
    return top_trends