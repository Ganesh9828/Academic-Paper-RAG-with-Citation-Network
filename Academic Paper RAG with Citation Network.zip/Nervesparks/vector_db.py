Sfrom sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings

class VectorDB:
    def __init__(self):
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.client = chromadb.Client(Settings())

        self.collection = self.client.create_collection("papers")

    def add_documents(self, docs):
        for i, doc in enumerate(docs):
            emb = self.model.encode(doc["text"])
            self.collection.add(
                documents=[doc["text"]],
                embeddings=[emb.tolist()],
                metadatas=[{"filename": doc["filename"]}],
                ids=[str(i)]
            )

    def search(self, query, top_k=3):
        emb = self.model.encode([query])
        result = self.collection.query(query_embeddings=emb, n_results=top_k)
        return result